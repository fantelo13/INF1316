#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>

#define FIFO_NAME "fifo_escalonador"

int main() {
    // Criação do FIFO, se não existir
    mkfifo(FIFO_NAME, 0666);

    pid_t pid_escalonador = fork();
    if (pid_escalonador == 0) {
        // Processo filho 1: escalonador
        execl("./escalonador", "escalonador", NULL);
        perror("Erro ao executar escalonador");
        exit(1);
    }

    pid_t pid_interpretador = fork();
    if (pid_interpretador == 0) {
        // Processo filho 2: interpretador
        execl("./interpretador", "interpretador", NULL);
        perror("Erro ao executar interpretador");
        exit(1);
    }

    // Processo pai: espera pelos filhos
    int status;
    waitpid(pid_escalonador, &status, 0);
    waitpid(pid_interpretador, &status, 0);

    printf("Executor finalizado.\n");
    return 0;
}
