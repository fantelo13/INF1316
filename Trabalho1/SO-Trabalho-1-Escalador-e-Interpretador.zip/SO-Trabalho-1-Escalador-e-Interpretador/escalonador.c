#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/stat.h>

#define FIFO_NAME "fifo_escalonador"
#define MAX_PROCESSES 20

typedef struct {
    pid_t pid;
    char nome[64];
    int prioridade;   // 0-7
    int inicio;       // Real-Time: início
    int duracao;      // Real-Time: duração
    int tipo;         // 0=RR, 1=PRIORIDADE, 2=REAL-TIME
    int tempo_executado; // para controle do PRIORIDADE
    int tempo_restante;  // para controle do REAL-TIME
} processo_t;

processo_t processos[MAX_PROCESSES];
int num_processos = 0;

void gerenciar_execucao(FILE *fifo_file) {
    int tempo = 0;
    static int rr_index = 0;

    while (1) {
        char buffer[256];
        int leu = 0;

        // Tenta ler uma nova linha do interpretador (FIFO)
        if (fgets(buffer, sizeof(buffer), fifo_file)) {
            buffer[strcspn(buffer, "\n")] = 0;
            if (strncmp(buffer, "Run ", 4) == 0) {
                leu = 1;
                char *token = strtok(buffer, " ");
                token = strtok(NULL, " ");
                if (token) {
                    char nome[64];
                    strcpy(nome, token);
                    int prioridade = -1, inicio = -1, duracao = -1;
                    while ((token = strtok(NULL, " "))) {
                        if (strncmp(token, "P=", 2) == 0) prioridade = atoi(token + 2);
                        else if (strncmp(token, "I=", 2) == 0) inicio = atoi(token + 2);
                        else if (strncmp(token, "D=", 2) == 0) duracao = atoi(token + 2);
                    }
                    pid_t pid = fork();
                    if (pid == 0) {
                        char path[70];
                        snprintf(path, sizeof(path), "./%s", nome);
                        execlp(path, nome, NULL);
                        perror("Erro ao executar programa");
                        exit(1);
                    } else {
                        processos[num_processos].pid = pid;
                        strcpy(processos[num_processos].nome, nome);
                        processos[num_processos].prioridade = prioridade;
                        processos[num_processos].inicio = inicio;
                        processos[num_processos].duracao = duracao;
                        processos[num_processos].tipo = (inicio != -1) ? 2 : (prioridade != -1) ? 1 : 0;
                        processos[num_processos].tempo_executado = 0;
                        processos[num_processos].tempo_restante = 0;
                        kill(pid, SIGSTOP);
                        num_processos++;
                    }
                }
            }
        }

        // Decidir quem executar no tempo atual
        processo_t *executando = NULL;

        // Real-Time
        for (int i = 0; i < num_processos; i++) {
            if (processos[i].tipo == 2) {
                int t = tempo % 60;
                if (t == processos[i].inicio) {
                    processos[i].tempo_restante = processos[i].duracao;
                }
                if (processos[i].tempo_restante > 0) {
                    executando = &processos[i];
                    break;
                }
            }
        }

        // Prioridade
        if (!executando) {
            int melhor_prioridade = 8;
            for (int i = 0; i < num_processos; i++) {
                if (processos[i].tipo == 1 && processos[i].tempo_executado < 3) {
                    if (processos[i].prioridade < melhor_prioridade) {
                        melhor_prioridade = processos[i].prioridade;
                        executando = &processos[i];
                    }
                }
            }
        }

        // Round-Robin
        if (!executando) {
            int tentativas = num_processos;
            while (tentativas--) {
                rr_index = (rr_index + 1) % num_processos;
                if (processos[rr_index].tipo == 0) {
                    executando = &processos[rr_index];
                    break;
                }
            }
        }

        // Executar ou imprimir ninguém
        if (executando) {
            printf("Tempo %d: %s\n", tempo, executando->nome);
            kill(executando->pid, SIGCONT);
            sleep(1);
            kill(executando->pid, SIGSTOP);
            if (executando->tipo == 1) executando->tempo_executado++;
            if (executando->tipo == 2) executando->tempo_restante--;
        } else {
            if (leu)
                printf("Tempo %d: ninguém (novo comando, mas não pode escalar)\n", tempo);
            else
                printf("Tempo %d: ninguém (aguardando novo comando)\n", tempo);
            sleep(1);
        }

        tempo++;
    }
}

int main() {
    mkfifo(FIFO_NAME, 0666);
    int fifo_fd = open(FIFO_NAME, O_RDONLY);
    if (fifo_fd < 0) {
        perror("Erro ao abrir FIFO");
        return 1;
    }

    FILE *fifo_file = fdopen(fifo_fd, "r");
    gerenciar_execucao(fifo_file);

    fclose(fifo_file);
    close(fifo_fd);
    return 0;
}
