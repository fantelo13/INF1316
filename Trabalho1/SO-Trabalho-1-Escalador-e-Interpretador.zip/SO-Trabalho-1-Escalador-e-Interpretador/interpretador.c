#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#define FIFO_NAME "fifo_escalonador"

int main() {
  FILE *file = fopen("exec.txt", "r");
  if (!file) {
    perror("Erro ao abrir exec.txt");
    return 1;
  }

  mkfifo(FIFO_NAME, 0666);
  int fifo_fd = open(FIFO_NAME, O_WRONLY);
  if (fifo_fd < 0) {
    perror("Erro ao abrir FIFO");
    fclose(file);
    return 1;
  }

  char line[256];
  while (fgets(line, sizeof(line), file)) {
    write(fifo_fd, line, strlen(line));
    printf("Interpretador enviou comando: %s", line);
    sleep(1); // Espera 1 segundo antes de enviar o próximo comando
  }

  close(fifo_fd);
  fclose(file);
  return 0;
}
